# FRISS FINANCE — Android APK

Aplikasi Android offline berbasis WebView lokal. Antarmuka dan data keuangan berjalan di dalam APK; tidak membutuhkan website/server.

## Build APK lewat GitHub
1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke root repository.
3. Buka tab **Actions** dan jalankan workflow **Build FRISS FINANCE APK** (atau push commit baru ke `main`).
4. Buka hasil workflow dan unduh artifact `FRISS-FINANCE-APK`.
5. Ekstrak artifact, lalu instal `app-debug.apk` di Android.

## Notifikasi
- Pengingat tugas: satu hari sebelum deadline pukul 19.00 dan pada hari deadline pukul 07.00.
- Pengingat harian pencatatan keuangan: sekitar pukul 21.00.
- Izinkan notifikasi saat aplikasi meminta izin. Android dapat menunda notifikasi karena optimasi baterai.

## Data
Data transaksi, target tabungan, dan tugas disimpan lokal di WebView. Gunakan fitur Backup secara berkala. Menghapus data aplikasi dapat menghapus catatan.
