# FRISS FINANCE Android — Blue White Animated

## Build APK via GitHub Actions
1. Upload the contents of this project folder to your GitHub repository (keep `.github/workflows/build-apk.yml`).
2. Push to the `main` branch, or open Actions and run **Build FRISS FINANCE APK** with **Run workflow**.
3. Open the completed workflow run and download the `FRISS-FINANCE-APK` artifact.
4. Extract the ZIP to get `app-debug.apk`.

Package: `com.friss.finance`
Version: `1.1` (versionCode 2)

This workflow creates a debug-signed APK. Debug signing may differ between builds/runners. If Android reports a signature conflict with an installed copy, back up/export any app data that matters, uninstall the old app, then install the new APK. The app's WebView localStorage is not guaranteed to survive uninstall.


## Perbaikan GitHub Actions
Workflow sudah diperbaiki agar mencari `settings.gradle` secara rekursif, termasuk jika project berada di folder bertingkat atau ZIP diekstrak ke `extracted/`.
