package com.friss.finance;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
 @Override public void onReceive(Context c,Intent i){
  String title=i.getStringExtra("title"); if(title==null)title="Ada pengingat dari FRISS FINANCE";
  Intent open=c.getPackageManager().getLaunchIntentForPackage(c.getPackageName());
  PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"friss_reminders"):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("FRISS FINANCE").setContentText(title).setStyle(new Notification.BigTextStyle().bigText(title)).setAutoCancel(true).setContentIntent(pi);
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); nm.notify((int)(System.currentTimeMillis()%100000),b.build());
 }
}
