package com.friss.finance;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReminderScheduler {
    static int code(String id, int offset){ return Math.abs((id+offset).hashCode()); }
    static void alarm(Context c, String id, String title, long when, int offset){
        if(when<=System.currentTimeMillis()) return;
        Intent i=new Intent(c,ReminderReceiver.class); i.putExtra("title",title); i.putExtra("kind","task");
        PendingIntent p=PendingIntent.getBroadcast(c,code(id,offset),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,when,p);
    }
    public static void schedule(Context c,String id,String title,String due){
        try{
            org.json.JSONArray all = new org.json.JSONArray(c.getSharedPreferences("reminders", Context.MODE_PRIVATE).getString("tasks", "[]"));
            org.json.JSONArray next = new org.json.JSONArray();
            for(int n=0;n<all.length();n++){ org.json.JSONObject o=all.getJSONObject(n); if(!id.equals(o.optString("id"))) next.put(o); }
            org.json.JSONObject saved = new org.json.JSONObject(); saved.put("id",id); saved.put("title",title); saved.put("due",due); next.put(saved);
            c.getSharedPreferences("reminders", Context.MODE_PRIVATE).edit().putString("tasks",next.toString()).apply();
            SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US); Date d=f.parse(due);
            Calendar day=Calendar.getInstance(); day.setTime(d); day.set(Calendar.HOUR_OF_DAY,7); day.set(Calendar.MINUTE,0); day.set(Calendar.SECOND,0);
            Calendar before=(Calendar)day.clone(); before.add(Calendar.DAY_OF_YEAR,-1); before.set(Calendar.HOUR_OF_DAY,19);
            alarm(c,id,title+" — deadline besok",before.getTimeInMillis(),1);
            alarm(c,id,title+" — deadline hari ini",day.getTimeInMillis(),2);
        }catch(Exception ignored){}
    }
    public static void cancel(Context c,String id){
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        for(int n=1;n<=2;n++){Intent i=new Intent(c,ReminderReceiver.class); PendingIntent p=PendingIntent.getBroadcast(c,code(id,n),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE); if(p!=null){am.cancel(p);p.cancel();}}
        try { org.json.JSONArray all=new org.json.JSONArray(c.getSharedPreferences("reminders",Context.MODE_PRIVATE).getString("tasks","[]")); org.json.JSONArray next=new org.json.JSONArray(); for(int n=0;n<all.length();n++){org.json.JSONObject o=all.getJSONObject(n);if(!id.equals(o.optString("id")))next.put(o);} c.getSharedPreferences("reminders",Context.MODE_PRIVATE).edit().putString("tasks",next.toString()).apply(); } catch(Exception ignored){}
    }
    public static void restore(Context c){
        try { org.json.JSONArray all=new org.json.JSONArray(c.getSharedPreferences("reminders",Context.MODE_PRIVATE).getString("tasks","[]")); for(int n=0;n<all.length();n++){org.json.JSONObject o=all.getJSONObject(n);scheduleAlarmsOnly(c,o.optString("id"),o.optString("title"),o.optString("due"));} } catch(Exception ignored){}
    }
    private static void scheduleAlarmsOnly(Context c,String id,String title,String due){
        try { SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US); Date d=f.parse(due); Calendar day=Calendar.getInstance();day.setTime(d);day.set(Calendar.HOUR_OF_DAY,7);day.set(Calendar.MINUTE,0);day.set(Calendar.SECOND,0);Calendar before=(Calendar)day.clone();before.add(Calendar.DAY_OF_YEAR,-1);before.set(Calendar.HOUR_OF_DAY,19);alarm(c,id,title+" — deadline besok",before.getTimeInMillis(),1);alarm(c,id,title+" — deadline hari ini",day.getTimeInMillis(),2); } catch(Exception ignored){}
    }
    public static void daily(Context c,boolean enabled){
        Intent i=new Intent(c,ReminderReceiver.class); i.putExtra("title","Jangan lupa catat pemasukan dan pengeluaran hari ini."); i.putExtra("kind","daily");
        PendingIntent p=PendingIntent.getBroadcast(c,99173,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(!enabled){am.cancel(p);p.cancel();return;}
        Calendar x=Calendar.getInstance(); x.set(Calendar.HOUR_OF_DAY,21); x.set(Calendar.MINUTE,0); x.set(Calendar.SECOND,0); if(x.getTimeInMillis()<=System.currentTimeMillis())x.add(Calendar.DAY_OF_YEAR,1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,x.getTimeInMillis(),AlarmManager.INTERVAL_DAY,p);
    }
}
