package com.friss.finance;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView web;
    private static final int REQ_NOTIF = 77;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(8,11,18));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(8,11,18));
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.rgb(8,11,18));
        WebSettings st = web.getSettings(); st.setJavaScriptEnabled(true); st.setDomStorageEnabled(true);
        st.setAllowFileAccess(true); st.setAllowContentAccess(true);
        web.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        createChannel();
    }
    @Override public void onBackPressed() { if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
    private void createChannel() { if(Build.VERSION.SDK_INT>=26){ android.app.NotificationChannel c=new android.app.NotificationChannel("friss_reminders","FRISS FINANCE",android.app.NotificationManager.IMPORTANCE_DEFAULT); c.setDescription("Pengingat tugas dan pencatatan keuangan"); getSystemService(android.app.NotificationManager.class).createNotificationChannel(c); } }
    public class AndroidBridge {
        Context c; AndroidBridge(Context c){this.c=c;}
        @JavascriptInterface public void requestNotificationPermission(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF); }
        @JavascriptInterface public void scheduleTaskReminder(String id,String title,String due){ ReminderScheduler.schedule(c,id,title,due); }
        @JavascriptInterface public void cancelTaskReminder(String id){ ReminderScheduler.cancel(c,id); }
        @JavascriptInterface public void enableDailyReminder(boolean enabled){ ReminderScheduler.daily(c,enabled); }
    }
}
